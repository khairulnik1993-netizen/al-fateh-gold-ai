# AL FATEH GOLD AI PRO V9 — Android Flutter source

## V9 changes
- TradingView-style XAUUSD M5 candlestick chart with EMA 20, EMA 50, and EMA 200 overlays.
- Dark chart panel with price grid and right-side price scale.
- English interface throughout.
- Premium dark and gold dashboard retained.
- Settings screen for MarketAPI key, push notifications, auto-refresh, and minimum signal score.
- Signal timeframe remains M5; higher minimum score values can reduce the number of signals.
- Quote status is read from MarketAPI. Signals and alerts are blocked unless the quote status is LIVE and no older than 120 seconds.
- MarketAPI quote request no longer filters out non-live quotes, allowing the app to display the provider status where a quote is returned.
- Auto-refresh every 60 seconds only while the app is open.

## Important limitations
- This source has not been built or tested on a physical Android device in this session.
- Signal calculations remain the V8 Dart approximation and must be validated against the original TradingView Pine Script.
- Signal history is session-only and is not a verified trade-performance ledger.
- Notifications and polling do not run reliably 24/7 after Android closes or kills the app. A foreground service or backend is required for continuous monitoring.
- MarketAPI prices are indicative source quotes, not your broker's execution prices. Broker bid/ask and fills can differ.
- Use a demo account first. No profit is guaranteed.

## API
- `GET /v1/bars` for XAUUSD M5/M15/M30/H1 history.
- `GET /v1/prices/latest?symbols=XAUUSD` for the latest quote and status.
- API key is sent in the Authorization Bearer header and stored locally with SharedPreferences.

## Build
Use Flutter 3.24.5, Java 17, and Android SDK. Run `flutter pub get`, then `flutter build apk --release`.
