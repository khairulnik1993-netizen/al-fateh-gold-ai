# AL FATEH GOLD AI PRO V8 — Android Flutter project

## Apa yang sudah ada dalam versi 1.1
- Dashboard XAUUSD dengan data MarketAPI.
- Kiraan signal BUY/SELL berasaskan indikator Pine V8 (implementasi Dart masih perlu dibandingkan dengan TradingView).
- Notifikasi Android untuk signal BUY/SELL baharu sahaja; tidak menghantar notifikasi WAIT.
- Auto-refresh setiap 60 saat **semasa aplikasi dibuka dan prosesnya hidup**.
- API key disimpan secara lokal menggunakan SharedPreferences.

## Had penting — belum siap untuk penggunaan background 24/7
Versi ini belum menjalankan pemeriksaan signal apabila Android menutup aplikasi atau menghentikan proses. Timer 60 saat hanya berjalan ketika app masih hidup. Untuk pemeriksaan background yang konsisten perlu ditambah servis Android foreground yang berterusan atau backend/cloud worker. WorkManager berkala Android lazimnya minimum 15 minit dan tidak sesuai untuk menjamin signal M5 tepat pada masa.

## Membina APK
Perlu Flutter 3.22+ / Dart 3.3+, Android SDK dan JDK yang serasi.

1. Extract projek.
2. Jalankan `flutter pub get`.
3. Pastikan `android/app/src/main/AndroidManifest.xml` digabungkan dengan scaffold Flutter Android standard (MainActivity Kotlin/Java dan resources styles diperlukan).
4. Jalankan `flutter run` untuk ujian.
5. Bina APK: `flutter build apk --release`.

Folder ini mengandungi source Flutter dan manifest, bukan APK siap pasang. APK belum dibina atau diuji pada telefon sebenar dalam sesi ini.

## API
- `GET https://api.marketapi.app/v1/bars` untuk XAUUSD M5/M15/M30/H1.
- `GET https://api.marketapi.app/v1/prices/latest?symbols=XAUUSD&require_live=true` untuk quote.
- Key dihantar melalui header `Authorization: Bearer ...`.

## Perhatian strategi
Pine Script asal menggunakan parameter minScore=65, ATR=14, SL ATR=1.0, buffer=0.2 dan target 30/60/90 × pipSize 0.10. Kiraan EMA/DMI/ADX/MACD dalam prototaip Dart masih pendekatan anggaran dan perlu diselaraskan tepat dengan Pine/TradingView. Pengurusan penuh state trade TP1/TP2/TP3/SL/expiry/cooldown juga belum selesai. Uji pada akaun demo dahulu; jangan gunakan signal ini sebagai jaminan keuntungan.
