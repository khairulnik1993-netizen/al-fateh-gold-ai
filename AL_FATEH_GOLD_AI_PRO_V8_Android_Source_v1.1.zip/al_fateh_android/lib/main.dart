
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

void main() => runApp(const AlFatehApp());

const gold = Color(0xFFD6B45A);
const bg = Color(0xFF090B10);
const panel = Color(0xFF151A23);
final FlutterLocalNotificationsPlugin notifications = FlutterLocalNotificationsPlugin();

Future<void> initNotifications() async {
  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  const settings = InitializationSettings(android: android);
  await notifications.initialize(settings);
  final androidPlugin = notifications.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
  await androidPlugin?.requestNotificationsPermission();
  const channel = AndroidNotificationChannel('al_fateh_signals', 'AL FATEH Signals', description: 'Isyarat BUY dan SELL XAUUSD', importance: Importance.max);
  await androidPlugin?.createNotificationChannel(channel);
}

class AlFatehApp extends StatelessWidget {
  const AlFatehApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AL FATEH GOLD AI',
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: gold, secondary: gold),
      cardColor: panel,
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: gold),
    ),
    home: const DashboardPage(),
  );
}

class Candle {
  final DateTime time;
  final double open, high, low, close;
  final bool complete;
  Candle(this.time, this.open, this.high, this.low, this.close, this.complete);
  factory Candle.fromJson(Map<String,dynamic> j) => Candle(
    DateTime.parse(j['time'].toString()).toUtc(),
    _n(j['open']), _n(j['high']), _n(j['low']), _n(j['close']), j['complete'] == true);
}
double _n(dynamic x) => x is num ? x.toDouble() : double.parse(x.toString());

class QuoteData {
  final double bid, ask;
  final DateTime time;
  final String status;
  QuoteData(this.bid,this.ask,this.time,this.status);
  double get mid => (bid+ask)/2;
}

class MarketApi {
  static const root='https://api.marketapi.app/v1';
  final String key;
  MarketApi(this.key);

  Future<List<Candle>> bars(String tf, int count) async {
    final now=DateTime.now().toUtc();
    final from=now.subtract(Duration(days: tf=='M5'?14:tf=='M15'||tf=='M30'?60:180));
    final uri=Uri.parse('$root/bars').replace(queryParameters:{
      'symbol':'XAUUSD','timeframe':tf,'from':from.toIso8601String(),
      'to':now.toIso8601String(),'limit':'$count'
    });
    final r=await http.get(uri,headers:{'Authorization':'Bearer $key'});
    if(r.statusCode!=200) throw Exception('API candle ${r.statusCode}: ${r.body}');
    final j=jsonDecode(r.body) as Map<String,dynamic>;
    final raw=(j['data'] as List).cast<Map<String,dynamic>>();
    final out=raw.map(Candle.fromJson).where((c)=>c.complete && c.time.isBefore(now)).toList()
      ..sort((a,b)=>a.time.compareTo(b.time));
    if(out.length<205) throw Exception('Data candle tidak cukup (${out.length}). Semak akses M5 XAUUSD.');
    return out;
  }

  Future<QuoteData> quote() async {
    final uri=Uri.parse('$root/prices/latest').replace(queryParameters:{
      'symbols':'XAUUSD','require_live':'true'
    });
    final r=await http.get(uri,headers:{'Authorization':'Bearer $key'});
    if(r.statusCode!=200) throw Exception('API harga ${r.statusCode}: ${r.body}');
    final j=jsonDecode(r.body) as Map<String,dynamic>;
    final rows=(j['data'] as List?) ?? [];
    if(rows.isEmpty) throw Exception('Harga XAUUSD tiada / bukan LIVE.');
    final q=rows.first as Map<String,dynamic>;
    return QuoteData(_n(q['bid']),_n(q['ask']),DateTime.parse(q['time']).toUtc(),q['status'].toString());
  }
}

double? emaAt(List<double> x,int period,int i) {
  if(i<period-1) return null;
  final k=2/(period+1);
  double v=x.take(period).reduce((a,b)=>a+b)/period;
  for(int n=period;n<=i;n++) v=x[n]*k+v*(1-k);
  return v;
}
List<double?> emaSeries(List<double> x,int p)=>List.generate(x.length,(i)=>emaAt(x,p,i));
double? rsiAt(List<double> c,int i,int p) {
  if(i<p) return null;
  double up=0,down=0;
  for(int k=i-p+1;k<=i;k++){final d=c[k]-c[k-1];if(d>0)up+=d;else down-=d;}
  if(down==0)return 100;
  final rs=(up/p)/(down/p); return 100-100/(1+rs);
}
double? atrAt(List<Candle> c,int i,int p) {
  if(i<p)return null; double sum=0;
  for(int k=i-p+1;k<=i;k++){
    final prev=c[k-1].close;
    sum+=math.max(c[k].high-c[k].low,math.max((c[k].high-prev).abs(),(c[k].low-prev).abs()));
  } return sum/p;
}
class Dmi { final double plus,minus,adx; Dmi(this.plus,this.minus,this.adx); }
Dmi? dmiAt(List<Candle> c,int i,int p) {
  if(i<p*2+1)return null;
  final trs=<double>[], pd=<double>[], md=<double>[];
  for(int k=1;k<=i;k++){
    final up=c[k].high-c[k-1].high, dn=c[k-1].low-c[k].low;
    pd.add(up>dn&&up>0?up:0); md.add(dn>up&&dn>0?dn:0);
    trs.add(math.max(c[k].high-c[k].low,math.max((c[k].high-c[k-1].close).abs(),(c[k].low-c[k-1].close).abs())));
  }
  final dx=<double>[];
  for(int k=p-1;k<trs.length;k++){
    final tr=trs.sublist(k-p+1,k+1).reduce((a,b)=>a+b);
    final a=pd.sublist(k-p+1,k+1).reduce((a,b)=>a+b)*100/tr;
    final b=md.sublist(k-p+1,k+1).reduce((a,b)=>a+b)*100/tr;
    dx.add((a+b)==0?0:(a-b).abs()/(a+b)*100);
  }
  if(dx.length<p)return null;
  final adx=dx.sublist(dx.length-p).reduce((a,b)=>a+b)/p;
  final tr=trs.sublist(trs.length-p).reduce((a,b)=>a+b);
  return Dmi(pd.sublist(pd.length-p).reduce((a,b)=>a+b)*100/tr,
    md.sublist(md.length-p).reduce((a,b)=>a+b)*100/tr,adx);
}
double? macdLineAt(List<double> c,int i) {
  final a=emaAt(c,12,i),b=emaAt(c,26,i); if(a==null||b==null)return null;return a-b;
}
double? macdSignalAt(List<double> c,int i) {
  if(i<33)return null;
  final vals=<double>[];
  for(int k=25;k<=i;k++){final m=macdLineAt(c,k);if(m!=null)vals.add(m);}
  if(vals.length<9)return null;
  return emaAt(vals,9,vals.length-1);
}
int trend(List<Candle> c) {
  if(c.length<52)return 0;
  final closes=c.map((e)=>e.close).toList(),i=closes.length-1;
  final e20=emaAt(closes,20,i),e50=emaAt(closes,50,i);
  if(e20==null||e50==null)return 0;
  return closes[i]>e20&&e20>e50?1:closes[i]<e20&&e20<e50?-1:0;
}
class SignalResult {
  final String direction,status;
  final int buyScore,sellScore;
  final double? entry,sl,tp1,tp2,tp3;
  final String trend,mtf;
  SignalResult(this.direction,this.status,this.buyScore,this.sellScore,this.entry,this.sl,this.tp1,this.tp2,this.tp3,this.trend,this.mtf);
}

SignalResult calculate(List<Candle> m5,List<Candle> m15,List<Candle> m30,List<Candle> h1) {
  // Use the last fully closed M5 bar, mirroring barstate.isconfirmed.
  final c=m5; final i=c.length-1; final closes=c.map((e)=>e.close).toList();
  final e20s=emaSeries(closes,20),e50s=emaSeries(closes,50),e200=emaAt(closes,200,i);
  final e20=e20s[i]!,e50=e50s[i]!,rsi=rsiAt(closes,i,14)??50;
  final dmi=dmiAt(c,i,14)??Dmi(0,0,0);
  final macd=macdLineAt(closes,i)??0, sig=macdSignalAt(closes,i)??0;
  final atr=atrAt(c,i,14)??0;
  final t15=trend(m15),t30=trend(m30),tH1=trend(h1);
  int buy=0,sell=0;
  if(e20>e50)buy+=10;if(c[i].close>e20)buy+=10;if(e20>(e20s[i-1]??e20))buy+=10;
  if(rsi>50)buy+=10;if(dmi.plus>dmi.minus)buy+=10;if(macd>sig)buy+=10;if(dmi.adx>=18)buy+=10;
  if(t15==1)buy+=10;if(t30==1)buy+=10;if(tH1==1)buy+=10;
  if(e20<e50)sell+=10;if(c[i].close<e20)sell+=10;if(e20<(e20s[i-1]??e20))sell+=10;
  if(rsi<50)sell+=10;if(dmi.minus>dmi.plus)sell+=10;if(macd<sig)sell+=10;if(dmi.adx>=18)sell+=10;
  if(t15==-1)sell+=10;if(t30==-1)sell+=10;if(tH1==-1)sell+=10;
  final rising=e20>(e20s[i-1]??e20)&&(e20s[i-1]??e20)>(e20s[i-2]??e20);
  final falling=e20<(e20s[i-1]??e20)&&(e20s[i-1]??e20)<(e20s[i-2]??e20);
  final bull=c[i].close>e20&&e20>e50&&rising;
  final bear=c[i].close<e20&&e20<e50&&falling;
  final mBuy=t15==1&&t30==1&&tH1!=-1;
  final mSell=t15==-1&&t30==-1&&tH1!=1;
  final body=(c[i].close-c[i].open).abs()>=atr*0.10;
  final buyTrig=((c[i].low<=e20&&c[i].close>e20)||(c[i].close>c[i-1].high&&c[i].close>e20))&&c[i].close>c[i].open&&body;
  final sellTrig=((c[i].high>=e20&&c[i].close<e20)||(c[i].close<c[i-1].low&&c[i].close<e20))&&c[i].close<c[i].open&&body;
  final lo=c.skip(math.max(0,c.length-5)).map((x)=>x.low).reduce(math.min)-atr*0.2;
  final hi=c.skip(math.max(0,c.length-5)).map((x)=>x.high).reduce(math.max)+atr*0.2;
  final longSL=math.min(lo,c[i].close-atr),shortSL=math.max(hi,c[i].close+atr);
  final buyOk=buy>=65&&buy>sell&&mBuy&&bull&&buyTrig&&dmi.adx>=18&&c[i].close-longSL>0;
  final sellOk=sell>=65&&sell>buy&&mSell&&bear&&sellTrig&&dmi.adx>=18&&shortSL-c[i].close>0;
  final direction=buyOk?'BUY':sellOk?'SELL':'WAIT';
  final entry=direction=='WAIT'?null:c[i].close;
  final sl=direction=='BUY'?longSL:direction=='SELL'?shortSL:null;
  return SignalResult(direction,direction=='WAIT'?'WAITING NEW SETUP':'NEW SIGNAL',buy,sell,entry,sl,
    entry==null?null:entry+(direction=='BUY'?3.0:-3.0),
    entry==null?null:entry+(direction=='BUY'?6.0:-6.0),
    entry==null?null:entry+(direction=='BUY'?9.0:-9.0),
    bull?'BULLISH':bear?'BEARISH':'NEUTRAL',
    t15==1&&t30==1?'M15/M30 BUY':t15==-1&&t30==-1?'M15/M30 SELL':'MIXED');
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override State<DashboardPage> createState()=>_DashboardPageState();
}
class _DashboardPageState extends State<DashboardPage> {
  String apiKey='';
  bool loading=false;
  String error='';
  QuoteData? quote;
  SignalResult? signal;
  Timer? timer;
  DateTime? updated;
  String lastNotifiedBar = '';
  final List<String> history=[];
  @override void initState(){super.initState();_boot();}
  Future<void> _boot() async {
    await initNotifications();
    await _loadKey();
  }
  void _startPolling() {
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 60), (_) => _refresh());
  }
  Future<void> _loadKey() async {
    final p=await SharedPreferences.getInstance();apiKey=p.getString('market_api_key')??'';
    if(apiKey.isNotEmpty){_startPolling();_refresh();}
  }
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> _saveKey(String value) async {
    final p=await SharedPreferences.getInstance();await p.setString('market_api_key',value.trim());
    setState(()=>apiKey=value.trim());_startPolling();_refresh();
  }
  Future<void> _refresh() async {
    if(apiKey.isEmpty||loading)return;
    setState(()=>loading=true);
    try {
      final api=MarketApi(apiKey);
      final results=await Future.wait([
        api.bars('M5',500),api.bars('M15',250),api.bars('M30',250),api.bars('H1',250),api.quote()
      ]);
      final s=calculate(results[0] as List<Candle>,results[1] as List<Candle>,results[2] as List<Candle>,results[3] as List<Candle>);
      final q=results[4] as QuoteData;
      if(!mounted)return;
      final barKey = (results[0] as List<Candle>).last.time.toIso8601String();
      final prefs = await SharedPreferences.getInstance();
      final previouslyNotified = prefs.getString('last_notified_m5_bar') ?? '';
      setState((){
        quote=q;signal=s;updated=DateTime.now();error='';
        if(s.direction!='WAIT' && barKey != previouslyNotified) {
          history.insert(0,'${DateTime.now().toLocal()} • ${s.direction} • ${s.entry?.toStringAsFixed(2)}');
        }
      });
      if(s.direction!='WAIT' && barKey != previouslyNotified) {
        await notifications.show(100, 'AL FATEH GOLD AI • ${s.direction}',
          'XAUUSD M5 | Score ${s.direction == 'BUY' ? s.buyScore : s.sellScore}%\nEntry ${s.entry?.toStringAsFixed(2)} | SL ${s.sl?.toStringAsFixed(2)}\nTP1 ${s.tp1?.toStringAsFixed(2)} • TP2 ${s.tp2?.toStringAsFixed(2)} • TP3 ${s.tp3?.toStringAsFixed(2)}',
          const NotificationDetails(android: AndroidNotificationDetails('al_fateh_signals','AL FATEH Signals',channelDescription:'Isyarat BUY dan SELL XAUUSD',importance:Importance.max,priority:Priority.high,styleInformation:BigTextStyleInformation(''))));
        await prefs.setString('last_notified_m5_bar', barKey);
        lastNotifiedBar = barKey;
      }
    } catch(e){if(mounted)setState(()=>error=e.toString());}
    finally {if(mounted)setState(()=>loading=false);}
  }
  Future<void> _keyDialog() async {
    final ctl=TextEditingController(text:apiKey);
    await showDialog(context:context,builder:(ctx)=>AlertDialog(
      backgroundColor:panel,title:const Text('MarketAPI Key'),
      content:TextField(controller:ctl,obscureText:true,decoration:const InputDecoration(hintText:'Masukkan API key')),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('BATAL')),
        ElevatedButton(onPressed:(){Navigator.pop(ctx);_saveKey(ctl.text);},child:const Text('SIMPAN'))]));
  }
  @override Widget build(BuildContext context) {
    final s=signal;
    return Scaffold(appBar:AppBar(title:const Text('AL FATEH GOLD AI',style:TextStyle(fontWeight:FontWeight.bold)),actions:[
      IconButton(onPressed:_keyDialog,icon:const Icon(Icons.key)),IconButton(onPressed:_refresh,icon:const Icon(Icons.refresh))]),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16),border:Border.all(color:gold.withOpacity(.5))),
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Text('XAUUSD • M5',style:TextStyle(color:gold,fontWeight:FontWeight.bold)),
            const SizedBox(height:8),
            Text(quote==null?'--':quote!.mid.toStringAsFixed(2),style:const TextStyle(fontSize:34,fontWeight:FontWeight.bold)),
            Text(quote==null?'Belum sambung API':'Bid ${quote!.bid}  •  Ask ${quote!.ask}  •  ${quote!.status}',style:const TextStyle(color:Colors.white70,fontSize:12)),
            if(updated!=null)Text('Dikemas kini: ${updated!.toLocal()}',style:const TextStyle(color:Colors.white54,fontSize:11)),
          ])),
        const SizedBox(height:14),
        Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16)),
          child:Column(children:[
            Text(s?.direction??'WAIT',style:TextStyle(fontSize:32,fontWeight:FontWeight.w900,color:s?.direction=='BUY'?Colors.greenAccent:s?.direction=='SELL'?Colors.redAccent:gold)),
            Text(s?.status??'MENUNGGU DATA',style:const TextStyle(color:Colors.white70)),
            const SizedBox(height:14),
            Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[
              _metric('BUY SCORE','${s?.buyScore??'--'}%'),
              _metric('SELL SCORE','${s?.sellScore??'--'}%'),
            ]),
          ])),
        const SizedBox(height:14),
        _section('TRADE LEVELS',[
          _level('ENTRY',s?.entry),_level('STOP LOSS',s?.sl),
          _level('TP1',s?.tp1),_level('TP2',s?.tp2),_level('TP3',s?.tp3),
        ]),
        const SizedBox(height:14),
        _section('FILTER STATUS',[
          _plain('Trend',s?.trend??'--'),_plain('M15 / M30',s?.mtf??'--'),
          _plain('Data source','MarketAPI • XAUUSD'),
          _plain('Signal timeframe','M5 (candle tutup sahaja)'),
          _plain('Auto refresh','Setiap 60 saat ketika aplikasi terbuka'),
          _plain('Notifikasi','BUY/SELL baharu sahaja'),
        ]),
        const SizedBox(height:14),
        _section('SIGNAL HISTORY',history.isEmpty?[_plain('Rekod','Belum ada signal dalam sesi ini')]:history.take(10).map((x)=>_plain('Signal',x)).toList()),
        if(loading)const Padding(padding:EdgeInsets.all(12),child:Center(child:CircularProgressIndicator(color:gold))),
        if(error.isNotEmpty)Container(margin:const EdgeInsets.only(top:12),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.red.withOpacity(.12),borderRadius:BorderRadius.circular(10)),child:Text(error,style:const TextStyle(color:Colors.redAccent))),
        const SizedBox(height:12),
        ElevatedButton.icon(onPressed:apiKey.isEmpty?_keyDialog:_refresh,icon:const Icon(Icons.sync),label:Text(apiKey.isEmpty?'MASUKKAN API KEY':'KEMAS KINI SIGNAL'),style:ElevatedButton.styleFrom(backgroundColor:gold,foregroundColor:bg,padding:const EdgeInsets.all(15))),
        const Padding(padding:EdgeInsets.only(top:14),child:Text('PERHATIAN: Signal ini menggunakan data API luar dan mungkin berbeza daripada harga HFM/Valetax. Uji pada demo dahulu. Aplikasi ini bukan nasihat kewangan dan tidak menjamin keuntungan.',style:TextStyle(color:Colors.white54,fontSize:11))),
      ]),
    );
  }
  Widget _metric(String a,String b)=>Column(children:[Text(a,style:const TextStyle(color:Colors.white54,fontSize:11)),Text(b,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold))]);
  Widget _section(String title,List<Widget> children)=>Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(14)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(color:gold,fontWeight:FontWeight.bold)),const Divider(color:Colors.white12),...children]));
  Widget _level(String name,double? v)=>_plain(name,v==null?'--':v.toStringAsFixed(2));
  Widget _plain(String a,String b)=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(a,style:const TextStyle(color:Colors.white70)),Flexible(child:Text(b,textAlign:TextAlign.right,style:const TextStyle(fontWeight:FontWeight.w600)))]));
}
