import fs from 'node:fs';
import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getMessaging } from 'firebase-admin/messaging';

const API_BASE = 'https://api.marketapi.app/v1';
const API_KEY = process.env.MARKETAPI_API_KEY;
const SERVICE_ACCOUNT_JSON = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
const TOPIC = process.env.FCM_TOPIC || 'alfateh-signals';
const STATE_PATH = new URL('./state.json', import.meta.url);
const NOW = Date.now();
const TF_MS = 5 * 60 * 1000;

function log(message) { console.log(`[${new Date().toISOString()}] ${message}`); }
function parseDate(v) {
  if (typeof v === 'number') return v < 1e12 ? v * 1000 : v;
  const n = Date.parse(String(v ?? ''));
  return Number.isFinite(n) ? n : NaN;
}
function pickArray(json) {
  for (const k of ['data', 'bars', 'candles', 'results', 'items']) {
    if (Array.isArray(json?.[k])) return json[k];
  }
  if (Array.isArray(json)) return json;
  return [];
}
function normalizeBar(x) {
  const time = x.time ?? x.timestamp ?? x.datetime ?? x.t ?? x.date;
  const o = Number(x.open ?? x.o), h = Number(x.high ?? x.h), l = Number(x.low ?? x.l), c = Number(x.close ?? x.c);
  const ms = parseDate(time);
  if (![o,h,l,c,ms].every(Number.isFinite)) return null;
  return { time: ms, o, h, l, c };
}
async function api(path) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { Authorization: `Bearer ${API_KEY}`, Accept: 'application/json' },
    signal: AbortSignal.timeout(15000)
  });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { throw new Error(`MarketAPI returned non-JSON HTTP ${res.status}`); }
  if (!res.ok) throw new Error(`MarketAPI HTTP ${res.status}: ${json.detail || json.message || json.code || 'request failed'}`);
  return json;
}
function ema(values, period) {
  if (values.length < period) return [];
  const a = 2 / (period + 1);
  let e = values.slice(0, period).reduce((s,v)=>s+v,0)/period;
  const out = Array(period - 1).fill(null); out.push(e);
  for (let i=period;i<values.length;i++) { e = values[i]*a + e*(1-a); out.push(e); }
  return out;
}
function atr(bars, period=14) {
  const trs=[];
  for (let i=1;i<bars.length;i++) trs.push(Math.max(bars[i].h-bars[i].l, Math.abs(bars[i].h-bars[i-1].c), Math.abs(bars[i].l-bars[i-1].c)));
  if (trs.length < period) return NaN;
  return trs.slice(-period).reduce((s,v)=>s+v,0)/period;
}
function readState() {
  try { return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8')); } catch { return { lastCandleTime: 0, lastDirection: 'WAIT' }; }
}
function writeState(s) { fs.writeFileSync(STATE_PATH, JSON.stringify(s, null, 2)); }
async function main() {
  if (!API_KEY) throw new Error('Missing MARKETAPI_API_KEY secret');
  if (!SERVICE_ACCOUNT_JSON) throw new Error('Missing FIREBASE_SERVICE_ACCOUNT_JSON secret');
  const account = JSON.parse(SERVICE_ACCOUNT_JSON);
  if (!getApps().length) initializeApp({ credential: cert(account) });

  // Check real quote first. No signal when quote is not explicitly LIVE or too old.
  const quoteJson = await api('/prices/latest?symbols=XAUUSD&require_live=true');
  const quote = (quoteJson.data || []).find(q => q.symbol === 'XAUUSD');
  if (!quote || quote.status !== 'LIVE') { log('NO SIGNAL: XAUUSD is not explicitly LIVE.'); return; }
  const quoteTime = parseDate(quote.time);
  if (!Number.isFinite(quoteTime) || NOW - quoteTime > 180000 || quoteTime > NOW + 30000) {
    log('NO SIGNAL: quote timestamp is stale/invalid.'); return;
  }

  const to = new Date(NOW).toISOString();
  const from = new Date(NOW - 4 * 24 * 60 * 60 * 1000).toISOString();
  const barsJson = await api(`/bars?symbol=XAUUSD&timeframe=M5&from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&limit=1000`);
  const bars = pickArray(barsJson).map(normalizeBar).filter(Boolean).sort((a,b)=>a.time-b.time);
  const unique = bars.filter((b,i)=>i===0 || b.time !== bars[i-1].time);
  if (unique.length < 210) { log(`NO SIGNAL: insufficient valid M5 bars (${unique.length}).`); return; }

  // Bar timestamps are assumed to be candle-open time. Only use a bar that has fully closed.
  const closed = unique.filter(b => b.time + TF_MS <= NOW - 5000);
  if (closed.length < 210) { log('NO SIGNAL: no sufficiently old closed candle.'); return; }
  const last = closed[closed.length - 1];
  const state = readState();
  if (last.time <= Number(state.lastCandleTime || 0)) { log('NO SIGNAL: candle already checked.'); return; }

  const closes = closed.map(b=>b.c);
  const e20 = ema(closes,20), e50 = ema(closes,50), e200 = ema(closes,200);
  const i = closed.length - 1;
  const volatility = atr(closed,14);
  if (!Number.isFinite(volatility) || volatility <= 0) { log('NO SIGNAL: ATR invalid.'); return; }
  const prev = closed[i-1];
  let buy=0, sell=0;
  if (e20[i] > e50[i]) buy += 25; else sell += 25;
  if (last.c > e20[i]) buy += 20; else sell += 20;
  if (e20[i] > e20[i-1]) buy += 15; else sell += 15;
  if (last.c > e200[i]) buy += 20; else sell += 20;
  if (last.c > last.o) buy += 20; else if (last.c < last.o) sell += 20;
  const direction = buy >= 70 && buy > sell ? 'BUY' : sell >= 70 && sell > buy ? 'SELL' : 'WAIT';
  state.lastCandleTime = last.time;
  state.lastDirection = direction;
  writeState(state);
  if (direction === 'WAIT') { log(`Candle checked; WAIT (buy ${buy}, sell ${sell}).`); return; }

  const entry = last.c;
  const risk = Math.max(volatility * 1.2, 0.01);
  const sign = direction === 'BUY' ? 1 : -1;
  const sl = entry - sign * risk;
  const tp1 = entry + sign * risk;
  const tp2 = entry + sign * risk * 1.5;
  const tp3 = entry + sign * risk * 2;
  const fmt = n => n.toFixed(2);
  const title = `${direction} XAUUSD • M5`;
  const body = `Entry ${fmt(entry)} | SL ${fmt(sl)} | TP1 ${fmt(tp1)} | TP2 ${fmt(tp2)} | TP3 ${fmt(tp3)}\nSkor arah: ${Math.max(buy,sell)}/100. Candle: ${new Date(last.time).toISOString()}. Feed MarketAPI LIVE.`;
  await getMessaging().send({
    topic: TOPIC,
    notification: { title, body },
    data: { symbol: 'XAUUSD', timeframe: 'M5', direction, entry: fmt(entry), sl: fmt(sl), tp1: fmt(tp1), tp2: fmt(tp2), tp3: fmt(tp3), candleTime: new Date(last.time).toISOString(), sourceStatus: 'LIVE' },
    android: { priority: 'high', notification: { channelId: 'alfateh_signals', sound: 'default' } }
  });
  log(`SENT ${direction}; entry=${fmt(entry)} score=${Math.max(buy,sell)}. This is an unvalidated starter strategy, not a verified profitable signal.`);
}
main().catch(err => { console.error(err.message || err); process.exitCode = 1; });
