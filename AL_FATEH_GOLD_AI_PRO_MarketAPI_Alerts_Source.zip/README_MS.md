# AL FATEH GOLD AI PRO — MarketAPI + Push Alerts (starter)

## Apa yang projek ini buat
- Menggantikan integrasi Twelve Data lama dengan backend worker yang memanggil MarketAPI `XAUUSD`.
- Memeriksa status quote `LIVE` dan umur timestamp; jika tidak live/lapuk, tiada signal dihantar.
- Mengambil candle M5, menapis candle yang dianggap sudah tutup, dan menggunakan contoh strategi EMA20/EMA50/EMA200 + ATR.
- Menghantar notifikasi ke topik Firebase Cloud Messaging `alfateh-signals`.
- GitHub Actions cuba menjalankan pemeriksaan setiap 5 minit. Ini BUKAN server berterusan: jadual GitHub boleh lewat atau terlepas, jadi ia tidak menjamin 24/7.

## Status penting — jangan anggap production-ready
Ini masih starter prototype, belum diuji terhadap akaun MarketAPI sebenar atau feed broker anda, dan belum disahkan sama dengan Pine Script V8.2 anda. Skor bukan kebarangkalian menang. Jangan guna untuk wang sebenar sebelum audit/backtest/forward-test.

## Kos dan had
- MarketAPI mendokumenkan 1,000 kredit percuma awal; kredit tidak semestinya diperbaharui setiap hari. Worker meminta harga terkini dan sejarah M5 bagi setiap larian; ini boleh menggunakan kira-kira 2 kredit setiap larian apabila kedua-dua endpoint memulangkan data, atau sekitar 576 kredit/hari jika larian benar-benar berlaku setiap 5 minit. Had/struktur billing boleh berubah; semak dashboard.
- GitHub Actions free quota dan jadual cron ada had dan tidak menjamin masa tepat.
- Firebase Cloud Messaging biasanya tiada caj untuk penghantaran push standard, tetapi konfigurasi projek Firebase diperlukan.
- Oleh itu ini ialah percubaan kos rendah, bukan jaminan 24 jam percuma selama-lamanya.

## Setup dari Android sahaja
### A. Sediakan Firebase (sekali sahaja)
1. Buka https://console.firebase.google.com/ dan cipta projek Firebase.
2. Tambah Android app dengan package name tepat `com.alfateh.goldai`.
3. Muat turun `google-services.json`. Jangan ubah nama fail. Fail ini bukan API key MarketAPI, tetapi tetap jangan post ke repositori awam jika mahu menjaga konfigurasi projek.
4. Untuk build APK melalui GitHub Actions, tambah GitHub repository secret bernama `GOOGLE_SERVICES_JSON` dan letakkan keseluruhan kandungan fail JSON sebagai nilainya. Alternatifnya, letak fail itu di `app/google-services.json` secara lokal sebelum build.
5. Aktifkan Cloud Messaging jika console memintanya.
6. Dalam Firebase Project Settings > Service accounts, jana private key JSON untuk Firebase Admin SDK. Simpan fail itu dengan selamat dan JANGAN upload ke repo. Tambah sebagai secret `FIREBASE_SERVICE_ACCOUNT_JSON` dengan keseluruhan kandungan JSON.

### B. Sediakan MarketAPI
1. Buka https://app.marketapi.app/docs dan dashboard API keys.
2. Cipta key dengan scope minimum yang diperlukan: `read:latest` dan `read:ohlcv` (nama scope perlu sepadan dengan yang dipaparkan di dashboard).
3. Dalam GitHub repository > Settings > Secrets and variables > Actions, tambah repository secret `MARKETAPI_API_KEY` dengan nilai key. Jangan letak key dalam kod, fail ZIP atau chat.

### C. Aktifkan monitor
1. Upload/commit folder projek ini ke repositori GitHub anda.
2. Tab Actions > pilih workflow `MarketAPI XAUUSD M5 signal monitor` > Run workflow untuk ujian manual.
3. Semak log. Jika key, scope, kredit atau format respons tidak betul, workflow akan gagal dan tiada signal patut dianggap live.
4. Workflow dijadualkan setiap 5 minit, tetapi GitHub Actions bukan server 24/7 dan cron boleh lewat. Untuk pemantauan benar-benar berterusan, gunakan worker hosting yang sentiasa aktif (biasanya berbayar).

### D. Bina APK
1. Actions > `Build AL FATEH GOLD AI PRO APK` > Run workflow.
2. Muat turun artifact `AL-FATEH-GOLD-AI-PRO-debug-apk` apabila build berjaya.
3. Pasang APK. Buka aplikasi sekali, benarkan notifikasi, dan semak status langganan Firebase.
4. Uji notifikasi melalui fungsi ujian Firebase Console sebelum bergantung pada signal pasaran.

## Tentang strategi
Worker ini menggunakan strategi starter yang ringkas: EMA20/50/200, arah candle, ambang skor 70/100 dan SL berdasarkan ATR (1.2 ATR; TP1 1R, TP2 1.5R, TP3 2R). Ia tidak mengaku sebagai salinan Pine Script V8.2 dan belum memasukkan pengesahan M15/M30/H1, RSI, MACD, ADX, expiry/cooldown dan state pengurusan trade seperti strategi penuh anda. Jangan anggap skor sebagai kebarangkalian menang.

## Keselamatan
- Jangan commit `MARKETAPI_API_KEY`, `FIREBASE_SERVICE_ACCOUNT_JSON`, atau private keys.
- Jika key pernah terdedah, revoke dan buat key baharu.
- Feed MarketAPI ialah feed data, bukan harga pelaksanaan broker anda; spread dan harga boleh berbeza.
- Notifikasi bukan arahan trading automatik dan bukan jaminan keuntungan.
