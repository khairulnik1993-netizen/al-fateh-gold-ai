plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Firebase configuration is enabled only after app/google-services.json is added.
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

android {
    namespace = "com.alfateh.goldai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.alfateh.goldai"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1-marketapi-alerts"
    }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:34.0.0"))
    implementation("com.google.firebase:firebase-messaging")
    implementation("androidx.core:core-ktx:1.15.0")
}
