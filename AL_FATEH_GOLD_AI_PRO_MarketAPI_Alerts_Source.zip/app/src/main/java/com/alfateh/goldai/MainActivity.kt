package com.alfateh.goldai

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 13, 20)
    private val panel = Color.rgb(24, 30, 42)
    private val gold = Color.rgb(255, 199, 35)
    private val green = Color.rgb(0, 220, 120)
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 20)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(text("♛ AL FATEH GOLD AI PRO", 25, gold, true))
        content.addView(text("XAUUSD • M5 • MarketAPI backend alerts", 14, Color.LTGRAY, false))
        status = text("STATUS: MENUNGGU KONFIGURASI FIREBASE", 15, Color.YELLOW, true)
        content.addView(card(status))
        content.addView(card(text("Aplikasi ini menerima notifikasi daripada backend. Ia tidak perlu kekal terbuka untuk menerima push notification, tetapi backend dan internet mesti tersedia.", 14, Color.WHITE, false)))
        content.addView(card(text("Data dan strategi", 18, gold, true)))
        content.addView(card(text("Backend menggunakan MarketAPI untuk XAUUSD. Signal hanya dihantar apabila quote berstatus LIVE dan candle M5 yang telah tutup memenuhi peraturan strategi. Strategi dalam pakej ini ialah contoh permulaan EMA/ATR, bukan pengesahan bahawa ia sama dengan Pine Script V8.2 anda.", 13, Color.LTGRAY, false)))
        val test = Button(this).apply { text = "SAMBUNG NOTIFIKASI" }
        content.addView(test)
        test.setOnClickListener { subscribeToTopic() }
        setContentView(root)
        requestNotificationPermissionIfNeeded()
        subscribeToTopic()
    }

    private fun subscribeToTopic() {
        try {
            FirebaseMessaging.getInstance().subscribeToTopic("alfateh-signals")
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        status.text = "STATUS: LANGGANAN NOTIFIKASI AKTIF"
                        status.setTextColor(green)
                    } else {
                        status.text = "STATUS: FIREBASE BELUM DISEDIAKAN / GAGAL"
                        status.setTextColor(Color.RED)
                    }
                }
        } catch (_: Exception) {
            status.text = "STATUS: TAMBAH app/google-services.json DAHULU"
            status.setTextColor(Color.RED)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); gravity = Gravity.START
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(8, 10, 8, 10)
    }

    private fun card(v: TextView) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(10, 6, 10, 6); setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 10, 0, 10)
        addView(v); v.layoutParams = LinearLayout.LayoutParams(-1, -2); layoutParams = lp
    }
}
