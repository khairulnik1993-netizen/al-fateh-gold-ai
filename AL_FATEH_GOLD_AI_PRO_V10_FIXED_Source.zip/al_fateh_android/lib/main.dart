
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' show DartPluginRegistrant;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_background_service/flutter_background_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await configureBackgroundService();
  runApp(const AlFatehApp());
}

Future<void> configureBackgroundService() async {
  // Create the persistent foreground-service channel before Android starts it.
  const channel = AndroidNotificationChannel(
    'al_fateh_background',
    'AL FATEH Background Monitor',
    description: 'Ongoing notification while XAUUSD is monitored',
    importance: Importance.low,
  );
  final localNotifications = FlutterLocalNotificationsPlugin();
  const initialization = InitializationSettings(
    android: AndroidInitializationSettings('@mipmap/ic_launcher'),
  );
  await localNotifications.initialize(initialization);
  final androidNotifications = localNotifications
      .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
  await androidNotifications?.createNotificationChannel(channel);

  final service = FlutterBackgroundService();
  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: backgroundServiceOnStart,
      autoStart: false,
      isForegroundMode: true,
      notificationChannelId: 'al_fateh_background',
      initialNotificationTitle: 'AL FATEH GOLD AI PRO',
      initialNotificationContent: 'Background signal monitor is ready',
      foregroundServiceNotificationId: 8801,
      foregroundServiceTypes: [AndroidForegroundType.dataSync],
    ),
    iosConfiguration: IosConfiguration(autoStart: false),
  );
}

@pragma('vm:entry-point')
void backgroundServiceOnStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();
  final localNotifications = FlutterLocalNotificationsPlugin();
  const init = InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher'));
  await localNotifications.initialize(init);
  const channel = AndroidNotificationChannel('al_fateh_signals', 'AL FATEH Signals',
      description: 'XAUUSD BUY and SELL signals', importance: Importance.max);
  final android = localNotifications.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
  await android?.createNotificationChannel(channel);

  if (service is AndroidServiceInstance) {
    await service.setAsForegroundService();
    await service.setForegroundNotificationInfo(
      title: 'AL FATEH GOLD AI PRO',
      content: 'Monitoring XAUUSD signals every 60 seconds',
    );
  }
  service.on('stopService').listen((_) => service.stopSelf());

  bool checkInProgress = false;
  Future<void> checkSignal() async {
    if (checkInProgress) return;
    checkInProgress = true;
    try {
    final prefs = await SharedPreferences.getInstance();
    final key = prefs.getString('market_api_key') ?? '';
    final enabled = prefs.getBool('auto_refresh_enabled') ?? true;
    final notify = prefs.getBool('notifications_enabled') ?? true;
    if (!enabled || key.isEmpty) return;
      final api = MarketApi(key);
      final results = await Future.wait([
        api.bars('M5', 500), api.bars('M15', 250), api.bars('M30', 250),
        api.bars('H1', 250), api.quote(),
      ]);
      final m5 = results[0] as List<Candle>;
      final quote = results[4] as QuoteData;
      final isLive = quote.status.toUpperCase() == 'LIVE' &&
          DateTime.now().toUtc().difference(quote.time).inSeconds.abs() <= 120;
      if (!isLive || m5.isEmpty) return;
      final score = prefs.getInt('minimum_signal_score') ?? 65;
      final signal = calculate(m5, results[1] as List<Candle>, results[2] as List<Candle>,
          results[3] as List<Candle>, minScore: score);
      final barKey = m5.last.time.toIso8601String();
      final previous = prefs.getString('last_notified_m5_bar') ?? '';
      if (notify && signal.direction != 'WAIT' && barKey != previous) {
        await localNotifications.show(
          100, 'AL FATEH GOLD AI • ${signal.direction}',
          'XAUUSD M5 | Score ${signal.direction == 'BUY' ? signal.buyScore : signal.sellScore}%\n'
          'Entry ${signal.entry?.toStringAsFixed(2)} | SL ${signal.sl?.toStringAsFixed(2)}\n'
          'TP1 ${signal.tp1?.toStringAsFixed(2)} • TP2 ${signal.tp2?.toStringAsFixed(2)} • TP3 ${signal.tp3?.toStringAsFixed(2)}',
          const NotificationDetails(android: AndroidNotificationDetails(
            'al_fateh_signals', 'AL FATEH Signals', channelDescription: 'XAUUSD BUY and SELL signals',
            importance: Importance.max, priority: Priority.high, styleInformation: BigTextStyleInformation(''))),
        );
        await prefs.setString('last_notified_m5_bar', barKey);
      }
    } catch (_) {
      // A temporary API/network failure is retried on the next polling cycle.
    } finally {
      checkInProgress = false;
    }
  }

  await checkSignal();
  Timer.periodic(const Duration(seconds: 60), (_) => checkSignal());
}


const gold = Color(0xFFD6B45A);
const bg = Color(0xFF090B10);
const panel = Color(0xFF151A23);
final FlutterLocalNotificationsPlugin notifications = FlutterLocalNotificationsPlugin();

Future<void> initNotifications() async {
  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  const settings = InitializationSettings(android: android);
  await notifications.initialize(settings);
  final androidPlugin = notifications.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
  await androidPlugin?.requestNotificationsPermission();
  const channel = AndroidNotificationChannel('al_fateh_signals', 'AL FATEH Signals', description: 'XAUUSD BUY and SELL signals', importance: Importance.max);
  await androidPlugin?.createNotificationChannel(channel);
}

class AlFatehApp extends StatelessWidget {
  const AlFatehApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AL FATEH GOLD AI PRO',
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: gold, secondary: gold),
      cardColor: panel,
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: gold),
    ),
    home: const DashboardPage(),
  );
}

class Candle {
  final DateTime time;
  final double open, high, low, close;
  final bool complete;
  Candle(this.time, this.open, this.high, this.low, this.close, this.complete);
  factory Candle.fromJson(Map<String,dynamic> j) => Candle(
    DateTime.parse(j['time'].toString()).toUtc(),
    _n(j['open']), _n(j['high']), _n(j['low']), _n(j['close']), j['complete'] == true);
}
double _n(dynamic x) => x is num ? x.toDouble() : double.parse(x.toString());

class QuoteData {
  final double bid, ask;
  final DateTime time;
  final String status;
  QuoteData(this.bid,this.ask,this.time,this.status);
  double get mid => (bid+ask)/2;
}

class MarketApi {
  static const root='https://api.marketapi.app/v1';
  final String key;
  MarketApi(this.key);

  Future<List<Candle>> bars(String tf, int count) async {
    final now=DateTime.now().toUtc();
    final from=now.subtract(Duration(days: tf=='M5'?14:tf=='M15'||tf=='M30'?60:180));
    final uri=Uri.parse('$root/bars').replace(queryParameters:{
      'symbol':'XAUUSD','timeframe':tf,'from':from.toIso8601String(),
      'to':now.toIso8601String(),'limit':'$count'
    });
    final r=await http.get(uri,headers:{'Authorization':'Bearer $key'});
    if(r.statusCode!=200) throw Exception('Candle API ${r.statusCode}: ${r.body}');
    final j=jsonDecode(r.body) as Map<String,dynamic>;
    final raw=(j['data'] as List).cast<Map<String,dynamic>>();
    final out=raw.map(Candle.fromJson).where((c)=>c.complete && c.time.isBefore(now)).toList()
      ..sort((a,b)=>a.time.compareTo(b.time));
    if(out.length<205) throw Exception('Insufficient candle data (${out.length}). Check XAUUSD history access.');
    return out;
  }

  Future<QuoteData> quote() async {
    final uri=Uri.parse('$root/prices/latest').replace(queryParameters:{
      'symbols':'XAUUSD'
    });
    final r=await http.get(uri,headers:{'Authorization':'Bearer $key'});
    if(r.statusCode!=200) throw Exception('Price API ${r.statusCode}: ${r.body}');
    final j=jsonDecode(r.body) as Map<String,dynamic>;
    final rows=(j['data'] as List?) ?? [];
    if(rows.isNotEmpty) {
      final q=rows.first as Map<String,dynamic>;
      return QuoteData(_n(q['bid']),_n(q['ask']),DateTime.parse(q['time']).toUtc(),q['status'].toString().toUpperCase());
    }
    final notLive=(j['not_live'] as List?) ?? [];
    if(notLive.isNotEmpty) {
      final q=notLive.first as Map<String,dynamic>;
      final status=(q['status'] ?? 'MARKET_CLOSED').toString().toUpperCase();
      final bid=q['bid'], ask=q['ask'], time=q['time'];
      if(bid!=null && ask!=null && time!=null) return QuoteData(_n(bid),_n(ask),DateTime.parse(time.toString()).toUtc(),status);
      throw Exception('XAUUSD status: $status');
    }
    throw Exception('XAUUSD quote unavailable. Check symbol access and API permissions.');
  }
}

double? emaAt(List<double> x,int period,int i) {
  if(i<period-1) return null;
  final k=2/(period+1);
  double v=x.take(period).reduce((a,b)=>a+b)/period;
  for(int n=period;n<=i;n++) v=x[n]*k+v*(1-k);
  return v;
}
List<double?> emaSeries(List<double> x,int p)=>List.generate(x.length,(i)=>emaAt(x,p,i));
double? rsiAt(List<double> c,int i,int p) {
  if(i<p) return null;
  double up=0,down=0;
  for(int k=i-p+1;k<=i;k++){final d=c[k]-c[k-1];if(d>0)up+=d;else down-=d;}
  if(down==0)return 100;
  final rs=(up/p)/(down/p); return 100-100/(1+rs);
}
double? atrAt(List<Candle> c,int i,int p) {
  if(i<p)return null; double sum=0;
  for(int k=i-p+1;k<=i;k++){
    final prev=c[k-1].close;
    sum+=math.max(c[k].high-c[k].low,math.max((c[k].high-prev).abs(),(c[k].low-prev).abs()));
  } return sum/p;
}
class Dmi { final double plus,minus,adx; Dmi(this.plus,this.minus,this.adx); }
Dmi? dmiAt(List<Candle> c,int i,int p) {
  if(i<p*2+1)return null;
  final trs=<double>[], pd=<double>[], md=<double>[];
  for(int k=1;k<=i;k++){
    final up=c[k].high-c[k-1].high, dn=c[k-1].low-c[k].low;
    pd.add(up>dn&&up>0?up:0); md.add(dn>up&&dn>0?dn:0);
    trs.add(math.max(c[k].high-c[k].low,math.max((c[k].high-c[k-1].close).abs(),(c[k].low-c[k-1].close).abs())));
  }
  final dx=<double>[];
  for(int k=p-1;k<trs.length;k++){
    final tr=trs.sublist(k-p+1,k+1).reduce((a,b)=>a+b);
    final a=pd.sublist(k-p+1,k+1).reduce((a,b)=>a+b)*100/tr;
    final b=md.sublist(k-p+1,k+1).reduce((a,b)=>a+b)*100/tr;
    dx.add((a+b)==0?0:(a-b).abs()/(a+b)*100);
  }
  if(dx.length<p)return null;
  final adx=dx.sublist(dx.length-p).reduce((a,b)=>a+b)/p;
  final tr=trs.sublist(trs.length-p).reduce((a,b)=>a+b);
  return Dmi(pd.sublist(pd.length-p).reduce((a,b)=>a+b)*100/tr,
    md.sublist(md.length-p).reduce((a,b)=>a+b)*100/tr,adx);
}
double? macdLineAt(List<double> c,int i) {
  final a=emaAt(c,12,i),b=emaAt(c,26,i); if(a==null||b==null)return null;return a-b;
}
double? macdSignalAt(List<double> c,int i) {
  if(i<33)return null;
  final vals=<double>[];
  for(int k=25;k<=i;k++){final m=macdLineAt(c,k);if(m!=null)vals.add(m);}
  if(vals.length<9)return null;
  return emaAt(vals,9,vals.length-1);
}
int trend(List<Candle> c) {
  if(c.length<52)return 0;
  final closes=c.map((e)=>e.close).toList(),i=closes.length-1;
  final e20=emaAt(closes,20,i),e50=emaAt(closes,50,i);
  if(e20==null||e50==null)return 0;
  return closes[i]>e20&&e20>e50?1:closes[i]<e20&&e20<e50?-1:0;
}
class SignalResult {
  final String direction,status;
  final int buyScore,sellScore;
  final double? entry,sl,tp1,tp2,tp3;
  final String trend,mtf;
  SignalResult(this.direction,this.status,this.buyScore,this.sellScore,this.entry,this.sl,this.tp1,this.tp2,this.tp3,this.trend,this.mtf);
}

SignalResult calculate(List<Candle> m5,List<Candle> m15,List<Candle> m30,List<Candle> h1,{int minScore=65}) {
  // Use the last fully closed M5 bar, mirroring barstate.isconfirmed.
  final c=m5; final i=c.length-1; final closes=c.map((e)=>e.close).toList();
  final e20s=emaSeries(closes,20),e50s=emaSeries(closes,50),e200=emaAt(closes,200,i);
  final e20=e20s[i]!,e50=e50s[i]!,rsi=rsiAt(closes,i,14)??50;
  final dmi=dmiAt(c,i,14)??Dmi(0,0,0);
  final macd=macdLineAt(closes,i)??0, sig=macdSignalAt(closes,i)??0;
  final atr=atrAt(c,i,14)??0;
  final t15=trend(m15),t30=trend(m30),tH1=trend(h1);
  int buy=0,sell=0;
  if(e20>e50)buy+=10;if(c[i].close>e20)buy+=10;if(e20>(e20s[i-1]??e20))buy+=10;
  if(rsi>50)buy+=10;if(dmi.plus>dmi.minus)buy+=10;if(macd>sig)buy+=10;if(dmi.adx>=18)buy+=10;
  if(t15==1)buy+=10;if(t30==1)buy+=10;if(tH1==1)buy+=10;
  if(e20<e50)sell+=10;if(c[i].close<e20)sell+=10;if(e20<(e20s[i-1]??e20))sell+=10;
  if(rsi<50)sell+=10;if(dmi.minus>dmi.plus)sell+=10;if(macd<sig)sell+=10;if(dmi.adx>=18)sell+=10;
  if(t15==-1)sell+=10;if(t30==-1)sell+=10;if(tH1==-1)sell+=10;
  final rising=e20>(e20s[i-1]??e20)&&(e20s[i-1]??e20)>(e20s[i-2]??e20);
  final falling=e20<(e20s[i-1]??e20)&&(e20s[i-1]??e20)<(e20s[i-2]??e20);
  final bull=c[i].close>e20&&e20>e50&&rising;
  final bear=c[i].close<e20&&e20<e50&&falling;
  final mBuy=t15==1&&t30==1&&tH1!=-1;
  final mSell=t15==-1&&t30==-1&&tH1!=1;
  final body=(c[i].close-c[i].open).abs()>=atr*0.10;
  final buyTrig=((c[i].low<=e20&&c[i].close>e20)||(c[i].close>c[i-1].high&&c[i].close>e20))&&c[i].close>c[i].open&&body;
  final sellTrig=((c[i].high>=e20&&c[i].close<e20)||(c[i].close<c[i-1].low&&c[i].close<e20))&&c[i].close<c[i].open&&body;
  final lo=c.skip(math.max(0,c.length-5)).map((x)=>x.low).reduce(math.min)-atr*0.2;
  final hi=c.skip(math.max(0,c.length-5)).map((x)=>x.high).reduce(math.max)+atr*0.2;
  final longSL=math.min(lo,c[i].close-atr),shortSL=math.max(hi,c[i].close+atr);
  final buyOk=buy>=minScore&&buy>sell&&mBuy&&bull&&buyTrig&&dmi.adx>=18&&c[i].close-longSL>0;
  final sellOk=sell>=minScore&&sell>buy&&mSell&&bear&&sellTrig&&dmi.adx>=18&&shortSL-c[i].close>0;
  final direction=buyOk?'BUY':sellOk?'SELL':'WAIT';
  final entry=direction=='WAIT'?null:c[i].close;
  final sl=direction=='BUY'?longSL:direction=='SELL'?shortSL:null;
  return SignalResult(direction,direction=='WAIT'?'WAITING NEW SETUP':'NEW SIGNAL',buy,sell,entry,sl,
    entry==null?null:entry+(direction=='BUY'?3.0:-3.0),
    entry==null?null:entry+(direction=='BUY'?6.0:-6.0),
    entry==null?null:entry+(direction=='BUY'?9.0:-9.0),
    bull?'BULLISH':bear?'BEARISH':'NEUTRAL',
    t15==1&&t30==1?'M15/M30 BUY':t15==-1&&t30==-1?'M15/M30 SELL':'MIXED');
}


class TradingChart extends StatelessWidget {
  final List<Candle> candles;
  final String timeframe;
  final ValueChanged<String> onTimeframeChanged;
  const TradingChart({super.key, required this.candles, required this.timeframe, required this.onTimeframeChanged});
  @override
  Widget build(BuildContext context) {
    const tfs=['M1','M5','M15','M30','H1','H4'];
    return Container(
      height: 340,
      padding: const EdgeInsets.fromLTRB(10, 12, 10, 8),
      decoration: BoxDecoration(color: const Color(0xFF0D1119), borderRadius: BorderRadius.circular(14), border: Border.all(color: gold.withOpacity(.28))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Text('XAUUSD', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
          const Spacer(),
          const Text('EMA 20', style: TextStyle(color: Color(0xFF42D6E8), fontSize: 10)),
          const SizedBox(width: 7), const Text('EMA 50', style: TextStyle(color: Color(0xFFFFD54F), fontSize: 10)),
          const SizedBox(width: 7), const Text('EMA 200', style: TextStyle(color: Color(0xFFB388FF), fontSize: 10)),
        ]),
        const SizedBox(height: 8),
        Wrap(spacing: 5, children: tfs.map((tf)=>ChoiceChip(label:Text(tf,style:const TextStyle(fontSize:10)),selected:timeframe==tf,onSelected:(_)=>onTimeframeChanged(tf),selectedColor:gold,labelStyle:TextStyle(color:timeframe==tf?bg:Colors.white70),backgroundColor:panel,visualDensity:VisualDensity.compact,padding:EdgeInsets.zero)).toList()),
        const SizedBox(height: 6),
        Expanded(child: candles.length < 30
          ? const Center(child: Text('Waiting for chart data', style: TextStyle(color: Colors.white54)))
          : _InteractiveChart(candles:candles)),
        const SizedBox(height: 4),
        const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('DRAG TO PAN  •  PINCH TO ZOOM  •  TAP CANDLE FOR OHLC', style: TextStyle(color: Colors.white38, fontSize: 9)),
          Text('LATEST', style: TextStyle(color: Colors.white38, fontSize: 9)),
        ]),
      ]),
    );
  }
}

class _InteractiveChart extends StatefulWidget {
  final List<Candle> candles;
  const _InteractiveChart({required this.candles});
  @override State<_InteractiveChart> createState()=>_InteractiveChartState();
}
class _InteractiveChartState extends State<_InteractiveChart> {
  int? selected;
  @override Widget build(BuildContext context) {
    final visible=widget.candles.length>90?widget.candles.sublist(widget.candles.length-90):widget.candles;
    return Column(children:[
      if(selected!=null && selected!>=0 && selected!<visible.length)
        Padding(padding:const EdgeInsets.only(bottom:4),child:Text('O ${visible[selected!].open.toStringAsFixed(2)}   H ${visible[selected!].high.toStringAsFixed(2)}   L ${visible[selected!].low.toStringAsFixed(2)}   C ${visible[selected!].close.toStringAsFixed(2)}',style:const TextStyle(color:gold,fontSize:10))),
      Expanded(child:LayoutBuilder(builder:(context,box){
        final chartWidth=math.max(box.maxWidth,900.0).toDouble();
        return ClipRect(child:InteractiveViewer(
          constrained:false, minScale:.65,maxScale:4, boundaryMargin:const EdgeInsets.all(120),
          child:GestureDetector(
            behavior:HitTestBehavior.opaque,
            onTapDown:(d){final plotW=chartWidth-60;final idx=((d.localPosition.dx/math.max(1,plotW))*visible.length).floor().clamp(0,visible.length-1);setState(()=>selected=idx);},
            child:SizedBox(width:chartWidth,height:box.maxHeight,child:CustomPaint(painter:_TradingChartPainter(widget.candles,selected))),
          ),
        ));
      })),
    ]);
  }
}

class _TradingChartPainter extends CustomPainter {
  final List<Candle> source; final int? selected;
  _TradingChartPainter(this.source,this.selected);
  @override
  void paint(Canvas canvas, Size size) {
    const rightSpace=54.0;
    final plot=Rect.fromLTWH(2,4,math.max(1,size.width-rightSpace-4),size.height-8);
    final start=math.max(0,source.length-90);
    final data=source.sublist(start);
    if(data.isEmpty)return;
    double lo=data.map((e)=>e.low).reduce(math.min),hi=data.map((e)=>e.high).reduce(math.max);
    final span=math.max(hi-lo,.01);lo-=span*.08;hi+=span*.08;
    double y(double v)=>plot.bottom-((v-lo)/(hi-lo))*plot.height;
    final grid=Paint()..color=Colors.white.withOpacity(.09)..strokeWidth=.6;
    for(int n=0;n<=4;n++){
      final yy=plot.top+plot.height*n/4;canvas.drawLine(Offset(plot.left,yy),Offset(plot.right+rightSpace,yy),grid);
      final price=hi-(hi-lo)*n/4;
      final tp=TextPainter(text:TextSpan(text:price.toStringAsFixed(2),style:const TextStyle(color:Colors.white54,fontSize:9)),textDirection:TextDirection.ltr)..layout(maxWidth:rightSpace-2);
      tp.paint(canvas,Offset(plot.right+5,yy-6));
    }
    final step=plot.width/data.length,bodyW=math.max(2.0,step*.62);
    for(int i=0;i<data.length;i++){
      final c=data[i],x=plot.left+step*(i+.5),up=c.close>=c.open;
      final paint=Paint()..color=(up?const Color(0xFF26A69A):const Color(0xFFEF5350))..strokeWidth=1.1;
      canvas.drawLine(Offset(x,y(c.high)),Offset(x,y(c.low)),paint);
      final top=y(math.max(c.open,c.close)),bottom=y(math.min(c.open,c.close));
      canvas.drawRect(Rect.fromLTRB(x-bodyW/2,top,x+bodyW/2,math.max(bottom,top+1.2)),paint);
      if(selected==i){final mark=Paint()..color=gold.withOpacity(.75)..strokeWidth=1;canvas.drawLine(Offset(x,plot.top),Offset(x,plot.bottom),mark);}
    }
    // EMA is calculated on the complete source history, then the visible tail is plotted.
    void drawEma(int period,Color color){
      final closes=source.map((e)=>e.close).toList();if(closes.length<period)return;
      final values=emaSeries(closes,period);final path=Path();bool started=false;
      for(int i=start;i<source.length;i++){final v=values[i];if(v==null)continue;final x=plot.left+step*((i-start)+.5),pt=Offset(x,y(v));if(!started){path.moveTo(pt.dx,pt.dy);started=true;}else{path.lineTo(pt.dx,pt.dy);}}
      canvas.drawPath(path,Paint()..color=color..strokeWidth=1.35..style=PaintingStyle.stroke);
    }
    drawEma(20,const Color(0xFF42D6E8));drawEma(50,const Color(0xFFFFD54F));drawEma(200,const Color(0xFFB388FF));
  }
  @override bool shouldRepaint(covariant _TradingChartPainter old)=>old.source!=source||old.selected!=selected;
}

class TradingSessions extends StatelessWidget {
  const TradingSessions({super.key});
  @override Widget build(BuildContext context){
    final now=DateTime.now();final mins=now.hour*60+now.minute;
    DateTime lastSunday(int year,int month){final last=DateTime(year,month+1,0);return last.subtract(Duration(days:last.weekday%7));}
    DateTime nthSunday(int year,int month,int nth){final first=DateTime(year,month,1);final firstSunday=first.add(Duration(days:(7-first.weekday)%7));return firstSunday.add(Duration(days:7*(nth-1)));}
    final ukDst= !now.isBefore(lastSunday(now.year,3)) && now.isBefore(lastSunday(now.year,10).add(const Duration(days:1)));
    final usDst= !now.isBefore(nthSunday(now.year,3,2)) && now.isBefore(nthSunday(now.year,11,1));
    bool inWindow(int start,int end)=>start<end?mins>=start&&mins<end:mins>=start||mins<end;
    final londonStart=ukDst?15*60:16*60, londonEnd=ukDst?0:60;
    final usStart=usDst?21*60+30:22*60+30, usEnd=usDst?4*60:5*60;
    final asia=inWindow(8*60,17*60),london=inWindow(londonStart,londonEnd),us=inWindow(usStart,usEnd);
    final overlap=london&&us;
    Widget item(String name,String hours,bool active)=>Expanded(child:Container(margin:const EdgeInsets.only(right:5),padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:active?gold.withOpacity(.16):panel,borderRadius:BorderRadius.circular(9),border:Border.all(color:active?gold.withOpacity(.65):Colors.white12)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(name,style:TextStyle(color:active?gold:Colors.white70,fontSize:10,fontWeight:FontWeight.bold)),Text(active?'ACTIVE':'CLOSED',style:TextStyle(color:active?Colors.greenAccent:Colors.white38,fontSize:9)),Text(hours,style:const TextStyle(color:Colors.white38,fontSize:8))])));
    return Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(12)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('TRADING SESSIONS • MYT',style:TextStyle(color:gold,fontWeight:FontWeight.bold,fontSize:12)),const SizedBox(height:8),Row(children:[item('ASIA','08:00–17:00',asia),item('LONDON',ukDst?'15:00–00:00':'16:00–01:00',london),item('US',usDst?'21:30–04:00':'22:30–05:00',us),item('OVERLAP','London + US',overlap)]),const SizedBox(height:5),const Text('London and US session hours adjust automatically for UK/US daylight-saving dates.',style:TextStyle(color:Colors.white38,fontSize:9))]));
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override State<DashboardPage> createState()=>_DashboardPageState();
}
class _DashboardPageState extends State<DashboardPage> {
  String apiKey='';
  bool loading=false;
  bool notificationsEnabled=true;
  bool autoRefreshEnabled=true;
  int minScore=65;
  String error='';
  QuoteData? quote;
  SignalResult? signal;
  Timer? timer;
  DateTime? updated;
  String lastNotifiedBar = '';
  final List<String> history=[];
  List<Candle> chartCandles=[];
  String chartTimeframe='M5';
  @override void initState(){super.initState();_boot();}
  Future<void> _boot() async {
    await initNotifications();
    await _loadKey();
  }
  void _startPolling() {
    // The foreground service owns the 60-second poll to avoid duplicate
    // notifications from a second in-app timer.
    timer?.cancel();
    _syncBackgroundMonitor();
  }
  Future<void> _syncBackgroundMonitor() async {
    final service = FlutterBackgroundService();
    if (apiKey.isNotEmpty && autoRefreshEnabled) {
      if (!await service.isRunning()) await service.startService();
    } else if (await service.isRunning()) {
      service.invoke('stopService');
    }
  }
  Future<void> _loadKey() async {
    final p=await SharedPreferences.getInstance();
    apiKey=p.getString('market_api_key')??'';
    notificationsEnabled=p.getBool('notifications_enabled')??true;
    autoRefreshEnabled=p.getBool('auto_refresh_enabled')??true;
    minScore=p.getInt('minimum_signal_score')??65;
    history.addAll(p.getStringList('signal_history')??<String>[]);
    if(apiKey.isNotEmpty){if(autoRefreshEnabled)_startPolling();_refresh();}
    if(mounted)setState((){});
  }
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> _saveKey(String value) async {
    final p=await SharedPreferences.getInstance();await p.setString('market_api_key',value.trim());
    setState(()=>apiKey=value.trim());_startPolling();_refresh();
  }
  Future<void> _changeChartTimeframe(String tf) async {
    if(tf==chartTimeframe)return;
    setState(()=>chartTimeframe=tf);
    if(apiKey.isEmpty)return;
    try {
      final bars=await MarketApi(apiKey).bars(tf,500);
      if(mounted)setState(()=>chartCandles=bars);
    } catch(e) { if(mounted)setState(()=>error='Chart $tf: $e'); }
  }
  Future<void> _refresh() async {
    if(apiKey.isEmpty||loading)return;
    setState(()=>loading=true);
    try {
      final api=MarketApi(apiKey);
      final results=await Future.wait([
        api.bars('M5',500),api.bars('M15',250),api.bars('M30',250),api.bars('H1',250),api.quote()
      ]);
      final rawSignal=calculate(results[0] as List<Candle>,results[1] as List<Candle>,results[2] as List<Candle>,results[3] as List<Candle>,minScore:minScore);
      final q=results[4] as QuoteData;
      final isLive=q.status.toUpperCase()=='LIVE' && DateTime.now().toUtc().difference(q.time).inSeconds.abs()<=120;
      final s=isLive?rawSignal:SignalResult('WAIT',q.status.toUpperCase()=='LIVE'?'STALE':'MARKET CLOSED',rawSignal.buyScore,rawSignal.sellScore,null,null,null,null,null,rawSignal.trend,rawSignal.mtf);
      if(!mounted)return;
      final barKey = (results[0] as List<Candle>).last.time.toIso8601String();
      final prefs = await SharedPreferences.getInstance();
      final previouslyNotified = prefs.getString('last_notified_m5_bar') ?? '';
      setState((){
        quote=q;signal=s;updated=DateTime.now();error='';
        chartCandles=List<Candle>.from(results[0] as List<Candle>);
        if(s.direction!='WAIT' && barKey != previouslyNotified) {
          history.insert(0,'${DateTime.now().toLocal()} • ${s.direction} • ${s.entry?.toStringAsFixed(2)}');
          if(history.length>100)history.removeRange(100,history.length);
        }
      });
      await prefs.setStringList('signal_history',history);
      if(chartTimeframe!='M5') { try { final chart=await api.bars(chartTimeframe,500); if(mounted)setState(()=>chartCandles=chart); } catch(_) {} }
      if(notificationsEnabled && s.direction!='WAIT' && barKey != previouslyNotified) {
        await notifications.show(100, 'AL FATEH GOLD AI • ${s.direction}',
          'XAUUSD M5 | Score ${s.direction == 'BUY' ? s.buyScore : s.sellScore}%\nEntry ${s.entry?.toStringAsFixed(2)} | SL ${s.sl?.toStringAsFixed(2)}\nTP1 ${s.tp1?.toStringAsFixed(2)} • TP2 ${s.tp2?.toStringAsFixed(2)} • TP3 ${s.tp3?.toStringAsFixed(2)}',
          const NotificationDetails(android: AndroidNotificationDetails('al_fateh_signals','AL FATEH Signals',channelDescription:'XAUUSD BUY and SELL signals',importance:Importance.max,priority:Priority.high,styleInformation:BigTextStyleInformation(''))));
        await prefs.setString('last_notified_m5_bar', barKey);
        lastNotifiedBar = barKey;
      }
    } catch(e){if(mounted)setState(()=>error=e.toString());}
    finally {if(mounted)setState(()=>loading=false);}
  }
  Future<void> _settingsDialog() async {
    bool notify=notificationsEnabled;
    bool auto=autoRefreshEnabled;
    int score=minScore;
    await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setDialog)=>AlertDialog(
      backgroundColor:panel,
      title:const Text('SETTINGS',style:TextStyle(color:gold)),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('API CONNECTION',style:TextStyle(color:gold,fontWeight:FontWeight.bold)),
        const SizedBox(height:6),
        Text(apiKey.isEmpty?'API key not configured':'API key saved securely on this device',style:const TextStyle(color:Colors.white70)),
        Align(alignment:Alignment.centerLeft,child:TextButton.icon(onPressed:(){Navigator.pop(ctx);_keyDialog();},icon:const Icon(Icons.vpn_key),label:const Text('Manage API Key'))),
        const Divider(color:Colors.white24),
        SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Push notifications'),subtitle:const Text('New BUY/SELL signals'),value:notify,activeColor:gold,onChanged:(v)=>setDialog(()=>notify=v)),
        SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Auto refresh'),subtitle:const Text('Every 60 seconds; foreground monitor may continue with screen off'),value:auto,activeColor:gold,onChanged:(v)=>setDialog(()=>auto=v)),
        const SizedBox(height:8),
        const Text('Minimum signal score',style:TextStyle(color:Colors.white70)),
        DropdownButton<int>(value:score,dropdownColor:panel,isExpanded:true,items:[65,70,75,80].map((v)=>DropdownMenuItem(value:v,child:Text('$v%'))).toList(),onChanged:(v){if(v!=null)setDialog(()=>score=v);}),
        const Text('Signal calculation remains on M5. Higher scores may reduce the number of signals.',style:TextStyle(color:Colors.white54,fontSize:11)),
        const SizedBox(height:8),
        const Text('Version 10.0 • XAUUSD',style:TextStyle(color:Colors.white54,fontSize:11)),
      ])),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('CANCEL')),ElevatedButton(onPressed:()async{
        final prefs=await SharedPreferences.getInstance();
        await prefs.setBool('notifications_enabled',notify);
        await prefs.setBool('auto_refresh_enabled',auto);
        await prefs.setInt('minimum_signal_score',score);
        if(!mounted)return;
        setState((){notificationsEnabled=notify;autoRefreshEnabled=auto;minScore=score;});
        _startPolling();Navigator.pop(ctx);_refresh();
      },child:const Text('SAVE'))],
    )));
  }

  Future<void> _keyDialog() async {
    final ctl=TextEditingController(text:apiKey);
    await showDialog(context:context,builder:(ctx)=>AlertDialog(
      backgroundColor:panel,title:const Text('MarketAPI API Key'),
      content:TextField(controller:ctl,obscureText:true,decoration:const InputDecoration(hintText:'Enter your API key')),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('CANCEL')),
        ElevatedButton(onPressed:(){Navigator.pop(ctx);_saveKey(ctl.text);},child:const Text('SAVE'))]));
  }
  @override Widget build(BuildContext context) {
    final s=signal;
    return Scaffold(appBar:AppBar(title:const Text('AL FATEH GOLD AI PRO',style:TextStyle(fontWeight:FontWeight.bold)),actions:[
      IconButton(tooltip:'Settings',onPressed:_settingsDialog,icon:const Icon(Icons.settings)),
      IconButton(tooltip:'Refresh',onPressed:_refresh,icon:const Icon(Icons.refresh))]),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16),border:Border.all(color:gold.withOpacity(.5))),
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Text('XAUUSD • M5 SIGNAL',style:TextStyle(color:gold,fontWeight:FontWeight.bold)),
            const SizedBox(height:8),
            Text(quote==null?'--':quote!.mid.toStringAsFixed(2),style:const TextStyle(fontSize:34,fontWeight:FontWeight.bold)),
            Text(quote==null?'API NOT CONNECTED':'Bid ${quote!.bid}  •  Ask ${quote!.ask}  •  ${quote!.status}',style:const TextStyle(color:Colors.white70,fontSize:12)),
            if(updated!=null)Text('Updated: ${updated!.toLocal()}',style:const TextStyle(color:Colors.white54,fontSize:11)),
          ])),
        const SizedBox(height:14),
        TradingChart(candles:chartCandles,timeframe:chartTimeframe,onTimeframeChanged:_changeChartTimeframe),
        const SizedBox(height:10),
        const TradingSessions(),
        const SizedBox(height:14),
        Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16)),
          child:Column(children:[
            Text(s?.direction??'WAIT',style:TextStyle(fontSize:32,fontWeight:FontWeight.w900,color:s?.direction=='BUY'?Colors.greenAccent:s?.direction=='SELL'?Colors.redAccent:gold)),
            Text(s?.status??'WAITING FOR DATA',style:const TextStyle(color:Colors.white70)),
            const SizedBox(height:14),
            Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[
              _metric('BUY SCORE','${s?.buyScore??'--'}%'),
              _metric('SELL SCORE','${s?.sellScore??'--'}%'),
            ]),
          ])),
        const SizedBox(height:14),
        _section('TRADE LEVELS',[
          _level('ENTRY',s?.entry),_level('STOP LOSS',s?.sl),
          _level('TP1',s?.tp1),_level('TP2',s?.tp2),_level('TP3',s?.tp3),
        ]),
        const SizedBox(height:14),
        _section('MARKET ANALYSIS',[
          _plain('Trend',s?.trend??'--'),_plain('M15 / M30',s?.mtf??'--'),
          _plain('Data source','MarketAPI • XAUUSD (indicative)'),
          _plain('Signal timeframe','M5 (closed candles only)'),
          _plain('Auto refresh','Every 60 seconds while app is open'),
          _plain('Notifications','New BUY/SELL signals only'),
        ]),
        const SizedBox(height:14),
        _section('SIGNAL HISTORY',history.isEmpty?[_plain('Records','No signals recorded this session')]:history.take(10).map((x)=>_plain('Signal',x)).toList()),
        if(loading)const Padding(padding:EdgeInsets.all(12),child:Center(child:CircularProgressIndicator(color:gold))),
        if(error.isNotEmpty)Container(margin:const EdgeInsets.only(top:12),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.red.withOpacity(.12),borderRadius:BorderRadius.circular(10)),child:Text(error,style:const TextStyle(color:Colors.redAccent))),
        const SizedBox(height:12),
        ElevatedButton.icon(onPressed:apiKey.isEmpty?_keyDialog:_refresh,icon:const Icon(Icons.sync),label:Text(apiKey.isEmpty?'ADD API KEY':'REFRESH SIGNAL'),style:ElevatedButton.styleFrom(backgroundColor:gold,foregroundColor:bg,padding:const EdgeInsets.all(15))),
        const Padding(padding:EdgeInsets.only(top:14),child:Text('IMPORTANT: Signals use external market data and may differ from your broker prices. Test on a demo account first. This app is not financial advice and does not guarantee profits.',style:TextStyle(color:Colors.white54,fontSize:11))),
      ]),
    );
  }
  Widget _metric(String a,String b)=>Column(children:[Text(a,style:const TextStyle(color:Colors.white54,fontSize:11)),Text(b,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold))]);
  Widget _section(String title,List<Widget> children)=>Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(14)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(color:gold,fontWeight:FontWeight.bold)),const Divider(color:Colors.white12),...children]));
  Widget _level(String name,double? v)=>_plain(name,v==null?'--':v.toStringAsFixed(2));
  Widget _plain(String a,String b)=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(a,style:const TextStyle(color:Colors.white70)),Flexible(child:Text(b,textAlign:TextAlign.right,style:const TextStyle(fontWeight:FontWeight.w600)))]));
}
