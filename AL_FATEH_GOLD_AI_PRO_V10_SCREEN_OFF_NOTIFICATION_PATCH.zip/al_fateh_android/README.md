# AL FATEH GOLD AI PRO V10 – Android Source

## Included in this V10 source update
- Interactive candlestick viewport: drag to pan and pinch to zoom.
- Tap a candle to inspect Open, High, Low and Close.
- Chart timeframe selector: M1, M5, M15, M30, H1 and H4 (subject to MarketAPI data access).
- EMA 20/50/200 calculated from the full loaded candle history before plotting the visible chart tail.
- Malaysia-time session panel for Asia, London, US and London/US overlap (indicative hours; daylight-saving shifts are noted).
- Signal history persisted locally on the device.
- V8-based signal calculation remains on M5; changing chart timeframe does not change the signal calculation.

## Important limitations in this build
This is an incremental source update, not a completed implementation of every previously discussed feature. The Android foreground background-monitor service is included in this source and polls every 60 seconds while enabled. Cloud monitoring, smart signal protection, risk calculator, connection monitor, economic-news integration/volatility filter and daily performance analytics are not included in this incremental build.

## Build
Use Flutter 3.24.5 or a compatible Flutter 3.x SDK. Run `flutter pub get` then `flutter build apk --release`.

MarketAPI access and historical data availability are required. Verify chart timeframe permissions with your API provider. No signal guarantees profit; test on demo first.


## Background signal monitoring (screen-off)
- Android foreground service checks the MarketAPI feed every 60 seconds while Auto Refresh is enabled and an API key is configured.
- New BUY/SELL alerts are sent only for a newly closed M5 bar, only when the quote status is LIVE and no older than 120 seconds.
- Android displays an ongoing notification while the monitor is active. Battery optimization, force-stop, vendor power management, API outages, and Android foreground-service time limits can interrupt monitoring. This is not guaranteed 24/7 delivery.
- Test on a demo account and verify notification permission and battery settings before relying on alerts.

## V10 screen-off monitor patch
- Background service configuration is now initialized during app startup.
- The monitor starts when a saved API key is present and Auto Refresh is enabled; it stops when Auto Refresh is disabled or the API key is cleared.
- To improve screen-off reliability on Android, allow notifications for AL FATEH GOLD AI and set the app battery usage to Unrestricted / Don't optimize (wording varies by phone). Also allow background data and do not force-stop the app.
- On some Android phones, vendor battery managers can still stop background work. This patch cannot guarantee alerts after force-stop, loss of internet, API outage, or OS restrictions.
