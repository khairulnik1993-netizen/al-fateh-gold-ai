package com.alfateh.goldai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 13, 20)
    private val panel = Color.rgb(24, 30, 42)
    private val gold = Color.rgb(255, 199, 35)
    private val green = Color.rgb(0, 220, 120)
    private val red = Color.rgb(255, 75, 85)
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var price: TextView
    private lateinit var signal: TextView
    private lateinit var levels: TextView
    private lateinit var keyInput: EditText
    private lateinit var refresh: Button
    private lateinit var save: Button
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 20)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(text("♛ AL FATEH GOLD AI PRO", 25, gold, true))
        content.addView(text("XAUUSD • M5 • Android", 14, Color.LTGRAY, false))
        status = text("STATUS: LIVE DATA BELUM DISEDIAKAN", 14, red, true)
        content.addView(card(status))
        price = text("Harga: --", 26, Color.WHITE, true)
        content.addView(card(price))
        signal = text("SIGNAL: TIADA
Signal hanya muncul selepas data pasaran sah diterima.", 18, Color.LTGRAY, true)
        content.addView(card(signal))
        levels = text("ENTRY: --\nSTOP LOSS: --\nTP1: --\nTP2: --\nTP3: --", 16, Color.WHITE, false)
        content.addView(card(levels))

        content.addView(text("Sambungan data pasaran", 18, gold, true))
        content.addView(text("Masukkan API key Twelve Data. Akaun dan pelan penyedia mungkin diperlukan untuk data XAU/USD intraday. Jangan masukkan kata laluan broker.", 13, Color.LTGRAY, false))
        keyInput = EditText(this).apply {
            hint = "Twelve Data API key"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(true); inputType = 0x00000081
            setBackgroundColor(panel)
            setPadding(14, 12, 14, 12)
        }
        content.addView(keyInput)
        save = Button(this).apply { text = "SIMPAN API KEY DI TELEFON" }
        content.addView(save)
        refresh = Button(this).apply { text = "SAMBUNG & SEMAK DATA" }
        content.addView(refresh)
        info = text("Keselamatan: API key disimpan setempat dalam app ini. Untuk penggunaan produksi, lebih selamat melalui backend sendiri.", 12, Color.GRAY, false)
        content.addView(card(info))
        content.addView(text("Nota: ini prototaip sumber. Signal tidak akan dianggap live sehingga API berjaya, candle lengkap diterima dan data disahkan. Belum ada jaminan prestasi atau keuntungan.", 12, Color.LTGRAY, false))

        setContentView(root)
        val prefs = getSharedPreferences("config", MODE_PRIVATE)
        keyInput.setText(prefs.getString("api_key", ""))
        save.setOnClickListener {
            prefs.edit().putString("api_key", keyInput.text.toString().trim()).apply()
            status.text = "STATUS: API KEY DISIMPAN — DATA BELUM DISAHKAN"
            status.setTextColor(gold)
            Toast.makeText(this, "API key disimpan pada telefon", Toast.LENGTH_SHORT).show()
        }
        refresh.setOnClickListener {
            val key = keyInput.text.toString().trim()
            if (key.isBlank()) {
                status.text = "STATUS: API KEY DIPERLUKAN — BUKAN LIVE"
                status.setTextColor(red)
                return@setOnClickListener
            }
            refresh.isEnabled = false
            status.text = "STATUS: MENYEMAK SUMBER DATA…"
            status.setTextColor(gold)
            worker.execute {
                try {
                    val candles = getCandles(key)
                    val result = calculate(candles)
                    runOnUiThread {
                        price.text = "Harga candle terakhir: ${fmt(result.close)}"
                        signal.text = "SIGNAL: ${result.direction}\nSkor teknikal: ${result.score}/100\nCandle: ${result.time}"
                        signal.setTextColor(if (result.direction == "BUY") green else if (result.direction == "SELL") red else Color.LTGRAY)
                        levels.text = "ENTRY: ${fmt(result.entry)}\nSTOP LOSS: ${fmt(result.sl)}\nTP1: ${fmt(result.tp1)}\nTP2: ${fmt(result.tp2)}\nTP3: ${fmt(result.tp3)}"
                        status.text = "STATUS: DATA API DITERIMA • SEMAK MASA & PELAN DATA"
                        status.setTextColor(green)
                        refresh.isEnabled = true
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        status.text = "STATUS: DATA GAGAL / TIDAK SAH — TIADA SIGNAL LIVE"
                        status.setTextColor(red)
                        signal.text = "SIGNAL: TIADA\nSemak API key, akses XAU/USD, kuota dan sambungan internet."
                        price.text = "Harga: --"
                        levels.text = "ENTRY: --\nSTOP LOSS: --\nTP1: --\nTP2: --\nTP3: --"
                        refresh.isEnabled = true
                    }
                }
            }
        }
    }

    private data class Candle(val time: String, val o: Double, val h: Double, val l: Double, val c: Double)
    private data class Result(val time: String, val close: Double, val direction: String, val score: Int,
                              val entry: Double, val sl: Double, val tp1: Double, val tp2: Double, val tp3: Double)

    private fun getCandles(key: String): List<Candle> {
        val encoded = URLEncoder.encode("XAU/USD", "UTF-8")
        val url = URL("https://api.twelvedata.com/time_series?symbol=$encoded&interval=5min&outputsize=250&apikey=${URLEncoder.encode(key, "UTF-8")}")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 12000; readTimeout = 12000
        }
        try {
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            if (json.has("status") && json.optString("status") == "error") throw Exception(json.optString("message"))
            val values = json.optJSONArray("values") ?: throw Exception("No candles")
            val list = mutableListOf<Candle>()
            for (i in values.length() - 1 downTo 0) {
                val v = values.getJSONObject(i)
                list.add(Candle(v.optString("datetime"), v.getString("open").toDouble(),
                    v.getString("high").toDouble(), v.getString("low").toDouble(), v.getString("close").toDouble()))
            }
            if (list.size < 210) throw Exception("Insufficient candles for EMA200")
            return list
        } finally { conn.disconnect() }
    }

    private fun calculate(c: List<Candle>): Result {
        val closes = c.map { it.c }
        fun ema(period: Int): List<Double> {
            val out = MutableList(closes.size) { Double.NaN }
            val alpha = 2.0 / (period + 1)
            var e = closes.take(period).average()
            out[period - 1] = e
            for (i in period until closes.size) { e = closes[i] * alpha + e * (1 - alpha); out[i] = e }
            return out
        }
        val e20 = ema(20); val e50 = ema(50); val e200 = ema(200)
        val i = c.lastIndex
        val last = c[i]
        val body = abs(last.c - last.o)
        val tr = (1..14).map { j ->
            val k = i - j + 1
            maxOf(c[k].h - c[k].l, abs(c[k].h - c[k-1].c), abs(c[k].l - c[k-1].c))
        }.average()
        var buy = 0; var sell = 0
        if (e20[i] > e50[i]) buy += 20 else sell += 20
        if (last.c > e20[i]) buy += 15 else sell += 15
        if (e20[i] > e20[i-1]) buy += 10 else sell += 10
        if (last.c > e200[i]) buy += 10 else sell += 10
        if (last.c > last.o) buy += 10 else if (last.c < last.o) sell += 10
        if (body >= tr * 0.10) { buy += if (last.c > last.o) 10 else 0; sell += if (last.c < last.o) 10 else 0 }
        val dir = if (buy >= 65 && buy > sell) "BUY" else if (sell >= 65 && sell > buy) "SELL" else "WAIT"
        val entry = last.c
        val sl = if (dir == "BUY") minOf(c.takeLast(5).minOf { it.l } - tr * 0.2, entry - tr)
                 else maxOf(c.takeLast(5).maxOf { it.h } + tr * 0.2, entry + tr)
        val pip = 0.10
        return Result(last.time, last.c, dir, maxOf(buy, sell), entry, if (dir == "WAIT") Double.NaN else sl,
            if (dir == "BUY") entry + 30*pip else if (dir == "SELL") entry - 30*pip else Double.NaN,
            if (dir == "BUY") entry + 60*pip else if (dir == "SELL") entry - 60*pip else Double.NaN,
            if (dir == "BUY") entry + 90*pip else if (dir == "SELL") entry - 90*pip else Double.NaN)
    }

    private fun fmt(v: Double): String = if (v.isNaN() || v.isInfinite()) "--" else String.format(java.util.Locale.US, "%.2f", v)
    private fun text(s: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); gravity = Gravity.START
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(8, 10, 8, 10)
    }
    private fun card(v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(10, 6, 10, 6); setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 10, 0, 10)
        addView(v); v.layoutParams = LinearLayout.LayoutParams(-1, -2)
        this.layoutParams = lp
    }
}
