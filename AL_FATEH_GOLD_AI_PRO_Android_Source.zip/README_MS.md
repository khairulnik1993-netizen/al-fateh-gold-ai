# AL FATEH GOLD AI PRO — Android source prototype

## Status
Ini ialah **projek sumber prototaip**, bukan APK yang telah dibina atau diuji. Ia sengaja tidak memaparkan harga/signal contoh sebagai data live.

## Data pasaran
Versi prototaip ini meminta API key Twelve Data dan cuba membaca candle `XAU/USD` pada sela 5 minit. Akses simbol, kuota, pelan, kelambatan data dan hak penggunaan mesti disahkan terus dengan penyedia. Broker pengguna belum dikenal pasti; feed ini bukan feed broker anda dan harga boleh berbeza.

## Amaran penting
- Enjin indikator dalam prototaip ini **belum setara dengan Pine Script V8 yang diberikan**: pengesahan M15/M30/H1, RSI, MACD, ADX, state TP/SL, expiry dan cooldown belum disepadukan sepenuhnya.
- Jangan gunakan untuk membuat keputusan wang sebenar. Skor bukan kebarangkalian menang dan tiada keuntungan dijamin.
- API key disimpan pada telefon dalam SharedPreferences biasa; untuk aplikasi produksi, gunakan backend perantara supaya kunci tidak terdedah.
- TP tetap menggunakan andaian 0.10 unit harga bagi satu pip. Sahkan konvensyen pip broker sebelum digunakan.
- Candle terakhir mungkin belum ditutup. Pengesahan candle tertutup, masa data dan stale-feed perlu ditambah sebelum menganggap signal boleh dagang.

## Cara bina APK
1. Pasang Android Studio pada komputer.
2. Buka folder projek ini.
3. Benarkan Gradle memuat turun plugin dan binaan yang diperlukan.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya diletakkan di `app/build/outputs/apk/debug/app-debug.apk`.

## Langkah sebelum live
1. Sahkan provider, akses XAU/USD intraday dan masa sebenar candle.
2. Implementasikan semula semua logik Pine V8 dan bandingkan output dengan TradingView.
3. Uji candle tertutup, spread/slippage, restart, sambungan putus, dan sentuhan SL/TP dalam candle sama.
4. Jalankan backtest dan forward-test; jangan anggap signal telah terbukti tepat.
