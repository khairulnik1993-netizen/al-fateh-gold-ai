package com.alfateh.goldai;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private EditText backendUrl;
    private TextView status, signal;
    private static final String CHANNEL_ID = "alfateh_signal_status";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 40, 36, 36);
        scroll.addView(layout);

        TextView title = new TextView(this);
        title.setText("AL FATEH GOLD AI PRO");
        title.setTextSize(24);
        title.setTextColor(Color.BLACK);
        layout.addView(title);

        TextView note = new TextView(this);
        note.setText("XAUUSD • Backend connection test\nMasukkan URL backend HTTPS anda. Jangan masukkan API key MarketAPI dalam aplikasi.");
        note.setTextSize(15);
        note.setPadding(0, 16, 0, 18);
        layout.addView(note);

        backendUrl = new EditText(this);
        backendUrl.setSingleLine(true);
        backendUrl.setHint("https://alamat-backend-anda");
        backendUrl.setTextSize(14);
        layout.addView(backendUrl);

        Button check = new Button(this);
        check.setText("SEMAK SIGNAL BACKEND");
        layout.addView(check);

        status = new TextView(this);
        status.setText("Status: Belum disambungkan");
        status.setTextSize(16);
        status.setPadding(0, 18, 0, 8);
        layout.addView(status);

        signal = new TextView(this);
        signal.setText("Signal: TIADA DATA");
        signal.setTextSize(20);
        signal.setPadding(0, 8, 0, 18);
        layout.addView(signal);

        TextView disclaimer = new TextView(this);
        disclaimer.setText("PENTING: Ini ialah rangka aplikasi. Ia tidak menjana signal live sendiri, tidak mengesahkan entry/SL/TP, dan tidak memantau 24/7. Backend mesti dibina dan diuji dahulu. Notifikasi latar 24/7 memerlukan backend serta Firebase Cloud Messaging.");
        disclaimer.setTextSize(13);
        layout.addView(disclaimer);
        setContentView(scroll);

        check.setOnClickListener(v -> checkBackend());
    }

    private void checkBackend() {
        String base = backendUrl.getText().toString().trim().replaceAll("/+$", "");
        if (!base.startsWith("https://")) {
            Toast.makeText(this, "Gunakan URL HTTPS backend yang sah", Toast.LENGTH_LONG).show();
            return;
        }
        status.setText("Status: Menyemak...");
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(base + "/signal");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                int code = conn.getResponseCode();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                    code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream()));
                StringBuilder body = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
                reader.close();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                JSONObject json = new JSONObject(body.toString());
                String symbol = json.optString("symbol", "XAUUSD");
                String action = json.optString("signal", "NO_SIGNAL");
                String price = json.optString("entry", "-");
                String sl = json.optString("sl", "-");
                String tp1 = json.optString("tp1", "-");
                String result = symbol + " | " + action + "\nEntry: " + price + "\nSL: " + sl + "\nTP1: " + tp1;
                runOnUiThread(() -> {
                    status.setText("Status: Backend bersambung");
                    signal.setText(result);
                });
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Ralat sambungan" : e.getMessage();
                runOnUiThread(() -> {
                    status.setText("Status: Gagal sambung — " + message);
                    signal.setText("Signal: TIADA DATA");
                });
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "AL FATEH Signal Status", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}
