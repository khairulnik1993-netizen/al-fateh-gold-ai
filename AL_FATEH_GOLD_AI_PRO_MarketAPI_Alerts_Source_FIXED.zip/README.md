# AL FATEH GOLD AI PRO — Android starter

This is a buildable Android starter project intended to verify the GitHub Actions APK pipeline.

## Build
GitHub Actions installs Gradle 8.9, so a checked-in `gradlew` wrapper is not required for this workflow. Open **Actions → Build AL FATEH GOLD AI PRO APK → Run workflow**. Download the APK from the completed run's Artifacts section.

## Important limitations
- This starter does not fetch MarketAPI directly and does not contain an API key.
- It expects your HTTPS backend to expose `GET /signal` returning JSON such as:
  `{"symbol":"XAUUSD","signal":"BUY","entry":"...","sl":"...","tp1":"..."}`
- It does not calculate or validate trading signals.
- It does not provide 24/7 background monitoring or push notifications yet. Those require a working backend and Firebase Cloud Messaging (FCM) configuration.
- Do not put MarketAPI secrets in this Android app or in a public GitHub repository.
- Treat all signals as informational, not financial advice.
