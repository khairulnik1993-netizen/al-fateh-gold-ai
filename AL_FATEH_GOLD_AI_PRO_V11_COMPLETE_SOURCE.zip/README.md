# AL FATEH GOLD AI PRO V11 – Android Source

## V11 trade lifecycle implementation
- XAUUSD signal calculation remains on completed M5 candles; chart timeframe selection does not change the signal timeframe.
- V8 defaults represented in the Android calculator: minimum score 65, ADX 18, strict M15/M30 alignment, H1 must not oppose, EMA/RSI/DMI/MACD scoring, pullback/breakout entry, ATR/swing stop and TP price offsets 3/6/9 (30/60/90 pips at pipSize 0.10).
- Persistent trade phases: WAIT → ACTIVE → TP1 → TP2 → TP3, or SL / EXPIRED.
- SL is checked before targets when both are touched in the same completed candle, matching the supplied Pine V8 rule.
- An ACTIVE trade expires after 3 subsequent completed M5 candles. After TP3, SL or expiry, the engine waits until more than 3 M5 bars have elapsed before accepting a new setup.
- Trade state and last processed M5 candle are stored locally, so foreground and background refreshes do not intentionally reprocess the same candle. The foreground dashboard leaves lifecycle processing to the Android service while that service is running.
- Background foreground-service polling interval: 60 seconds. Signal and trade-state changes can trigger notifications.

## Android build
The repository includes `android/app/src/main/AndroidManifest.xml`; the GitHub Actions workflow creates the Flutter Android wrapper and copies the manifest and Dart source before building a release APK. Flutter version in workflow: 3.24.5.

## Screen-off requirements and limitations
1. Configure the MarketAPI key in the app and enable Push notifications + Auto refresh.
2. Grant Android notification permission.
3. On Infinix/XOS, allow Auto-start and set battery use to Unrestricted / Don't optimize.
4. Do not Force stop the app. Confirm the persistent foreground-service notification appears.
5. Android and device manufacturers can still stop background work; 60-second polling is best-effort, not guaranteed 24/7. Android 15+ also applies runtime limits to dataSync foreground services. A cloud push backend would be needed for stronger delivery guarantees.

## Important validation notes
- This source has not been compiled in this environment because Flutter SDK is unavailable here. Run the GitHub Actions workflow and check its build result before installing.
- Pine Script and the app must use the same XAUUSD candle feed/timezone/session to validate exact signal parity. MTF candle alignment and indicator seeding should be compared candle-by-candle with TradingView. This is a V8-inspired implementation, not a claim of verified 100% TradingView parity.
- MarketAPI HTTP 502 is an upstream provider/gateway error; the app can retry and report it but cannot repair the provider outage.
- MarketAPI prices can differ from HFM/Valetax MT5 quotes. Test on demo first; no signal guarantees profit.
